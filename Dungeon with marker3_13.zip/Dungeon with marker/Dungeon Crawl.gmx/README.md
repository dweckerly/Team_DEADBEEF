## Text-based character controller
